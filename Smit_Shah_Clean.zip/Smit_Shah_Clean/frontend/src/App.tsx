import { IGF1InputWorkflow } from './features/igf1/IGF1InputWorkflow';
import { AppShell } from './components/layout/AppShell';

function App() {
  return (
    <AppShell>
      <IGF1InputWorkflow />
    </AppShell>
  );
}

export default App;
