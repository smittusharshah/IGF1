import { SiCaffeine } from 'react-icons/si';
import { Activity } from 'lucide-react';

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-white/80 backdrop-blur-md shadow-sm">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 py-4">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 shadow-md shadow-indigo-200/50">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-foreground">
                IGF-1 SDS Calculator
              </h1>
              <p className="text-xs text-muted-foreground leading-none">
                Indian pediatric normative reference data
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 sm:px-6 lg:px-8 py-8 max-w-3xl">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-white/60 backdrop-blur-sm mt-auto">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="space-y-4">
            <div className="rounded-lg bg-muted/50 border border-border/40 px-4 py-3">
              <p className="text-xs font-medium text-muted-foreground mb-1">Reference</p>
              <p className="text-xs text-muted-foreground/80 leading-relaxed">
                Teja, K. V. R., Malhotra, B., Vogel, M., Marwaha, R. K., Aggarwal, A., Pal, R., Das, L., Sachdeva, N., Devi, N., Bansal, D., Rastogi, A., Sharma, S., Gajinder, D., Bhadada, S. K., Ghosh, J., Monaghan, P. J., Korbonits, M., &amp; Dutta, P. (2024). Normative data for Insulin-Like growth Factor 1 in healthy children and adolescents from India. <em>The Journal of Clinical Endocrinology &amp; Metabolism</em>, 109(12), 3146–3155.{' '}
                <a
                  href="https://doi.org/10.1210/clinem/dgae340"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary hover:underline font-medium"
                >
                  https://doi.org/10.1210/clinem/dgae340
                </a>
              </p>
            </div>
            <div className="text-center py-2">
              <p className="text-sm font-semibold text-foreground tracking-wide">
                Prepared &amp; Developed by{' '}
                <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent font-bold">
                  Dr. Smit Shah
                </span>
              </p>
            </div>
            <p className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
              Built with <SiCaffeine className="w-3.5 h-3.5 text-amber-600" />{' '}
              <a
                href="https://caffeine.ai"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline font-medium"
              >
                caffeine.ai
              </a>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
