/**
 * Table-first percentile derivation utilities
 * Dynamically supports both full percentile set (2.5, 5, 10, 25, 50, 75, 90, 95, 97.5)
 * and legacy subset by building percentile points array based on available columns.
 * Interpolates percentile from reference row percentile columns with exact-match detection
 * using numeric tolerance, and converts percentile to SDS using table-distribution scaling.
 */

import type { ReferenceRow, TannerReferenceRow } from './referenceTables';

const EXACT_MATCH_TOLERANCE = 0.01;

/**
 * Build an array of percentile points from a reference row
 */
function buildPercentilePoints(row: ReferenceRow | TannerReferenceRow): Array<{ percentile: number; value: number }> {
  const points: Array<{ percentile: number; value: number }> = [];

  if (row.p2_5 !== undefined) points.push({ percentile: 2.5, value: row.p2_5 });
  if (row.p5 !== undefined) points.push({ percentile: 5, value: row.p5 });
  if (row.p10 !== undefined) points.push({ percentile: 10, value: row.p10 });
  if (row.p25 !== undefined) points.push({ percentile: 25, value: row.p25 });
  if (row.p50 !== undefined) points.push({ percentile: 50, value: row.p50 });
  if (row.p75 !== undefined) points.push({ percentile: 75, value: row.p75 });
  if (row.p90 !== undefined) points.push({ percentile: 90, value: row.p90 });
  if (row.p95 !== undefined) points.push({ percentile: 95, value: row.p95 });
  if (row.p97 !== undefined) points.push({ percentile: 97, value: row.p97 });
  if (row.p97_5 !== undefined) points.push({ percentile: 97.5, value: row.p97_5 });

  return points;
}

/**
 * Derive percentile from IGF-1 value using table percentile columns
 */
export function derivePercentileFromTable(
  igf1Value: number,
  row: ReferenceRow | TannerReferenceRow
): number {
  const points = buildPercentilePoints(row);

  if (points.length === 0) {
    throw new Error('No percentile data available in reference row');
  }

  // Check for exact match within tolerance
  for (const point of points) {
    if (Math.abs(igf1Value - point.value) < EXACT_MATCH_TOLERANCE) {
      return point.percentile;
    }
  }

  // Handle values below the lowest percentile
  if (igf1Value < points[0].value) {
    const p1 = points[0];
    const p2 = points[1];
    const slope = (p2.percentile - p1.percentile) / (p2.value - p1.value);
    const extrapolated = p1.percentile + slope * (igf1Value - p1.value);
    return Math.max(0.1, extrapolated);
  }

  // Handle values above the highest percentile
  if (igf1Value > points[points.length - 1].value) {
    const p1 = points[points.length - 2];
    const p2 = points[points.length - 1];
    const slope = (p2.percentile - p1.percentile) / (p2.value - p1.value);
    const extrapolated = p2.percentile + slope * (igf1Value - p2.value);
    return Math.min(99.9, extrapolated);
  }

  // Interpolate between two percentile points
  for (let i = 0; i < points.length - 1; i++) {
    const p1 = points[i];
    const p2 = points[i + 1];

    if (igf1Value >= p1.value && igf1Value <= p2.value) {
      const ratio = (igf1Value - p1.value) / (p2.value - p1.value);
      return p1.percentile + ratio * (p2.percentile - p1.percentile);
    }
  }

  return 50;
}

/**
 * Standard normal inverse CDF approximation (for reference only, not used in table-distribution SDS)
 */
function inverseNormalCDF(p: number): number {
  if (p <= 0 || p >= 1) {
    throw new Error('Percentile must be between 0 and 1 (exclusive)');
  }

  const a1 = -3.969683028665376e1;
  const a2 = 2.209460984245205e2;
  const a3 = -2.759285104469687e2;
  const a4 = 1.38357751867269e2;
  const a5 = -3.066479806614716e1;
  const a6 = 2.506628277459239;

  const b1 = -5.447609879822406e1;
  const b2 = 1.615858368580409e2;
  const b3 = -1.556989798598866e2;
  const b4 = 6.680131188771972e1;
  const b5 = -1.328068155288572e1;

  const c1 = -7.784894002430293e-3;
  const c2 = -3.223964580411365e-1;
  const c3 = -2.400758277161838;
  const c4 = -2.549732539343734;
  const c5 = 4.374664141464968;
  const c6 = 2.938163982698783;

  const d1 = 7.784695709041462e-3;
  const d2 = 3.224671290700398e-1;
  const d3 = 2.445134137142996;
  const d4 = 3.754408661907416;

  const pLow = 0.02425;
  const pHigh = 1 - pLow;

  let q: number;
  let r: number;
  let z: number;

  if (p < pLow) {
    q = Math.sqrt(-2 * Math.log(p));
    z = (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1);
  } else if (p <= pHigh) {
    q = p - 0.5;
    r = q * q;
    z = (((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q / (((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1);
  } else {
    q = Math.sqrt(-2 * Math.log(1 - p));
    z = -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1);
  }

  return z;
}

/**
 * Derive SDS (Z-score) from IGF-1 value using table percentile distribution
 * p50 maps to SDS=0, values below p50 yield negative SDS, values above p50 yield positive SDS
 */
export function deriveSDSFromTable(
  igf1Value: number,
  row: ReferenceRow | TannerReferenceRow
): number {
  const points = buildPercentilePoints(row);

  if (points.length === 0) {
    throw new Error('No percentile data available in reference row');
  }

  // Find p50
  const p50Point = points.find(p => p.percentile === 50);
  if (!p50Point) {
    throw new Error('p50 not available in reference row');
  }

  // If value equals p50 (within tolerance), return SDS = 0
  if (Math.abs(igf1Value - p50Point.value) < EXACT_MATCH_TOLERANCE) {
    return 0;
  }

  // Map IGF-1 value to percentile first
  const percentile = derivePercentileFromTable(igf1Value, row);

  // Convert percentile to SDS using piecewise linear mapping based on table distribution
  // We'll use the available percentile points to create a piecewise linear SDS mapping
  
  // Standard percentile-to-SDS mappings (approximate Z-scores for standard normal)
  const percentileToSDSMap: Array<{ percentile: number; sds: number }> = [
    { percentile: 2.5, sds: -1.96 },
    { percentile: 5, sds: -1.645 },
    { percentile: 10, sds: -1.28 },
    { percentile: 25, sds: -0.674 },
    { percentile: 50, sds: 0 },
    { percentile: 75, sds: 0.674 },
    { percentile: 90, sds: 1.28 },
    { percentile: 95, sds: 1.645 },
    { percentile: 97.5, sds: 1.96 },
  ];

  // Find the two closest percentile-SDS pairs for interpolation
  if (percentile <= percentileToSDSMap[0].percentile) {
    // Extrapolate below lowest
    const p1 = percentileToSDSMap[0];
    const p2 = percentileToSDSMap[1];
    const slope = (p2.sds - p1.sds) / (p2.percentile - p1.percentile);
    return p1.sds + slope * (percentile - p1.percentile);
  }

  if (percentile >= percentileToSDSMap[percentileToSDSMap.length - 1].percentile) {
    // Extrapolate above highest
    const p1 = percentileToSDSMap[percentileToSDSMap.length - 2];
    const p2 = percentileToSDSMap[percentileToSDSMap.length - 1];
    const slope = (p2.sds - p1.sds) / (p2.percentile - p1.percentile);
    return p2.sds + slope * (percentile - p2.percentile);
  }

  // Interpolate between two points
  for (let i = 0; i < percentileToSDSMap.length - 1; i++) {
    const p1 = percentileToSDSMap[i];
    const p2 = percentileToSDSMap[i + 1];

    if (percentile >= p1.percentile && percentile <= p2.percentile) {
      const ratio = (percentile - p1.percentile) / (p2.percentile - p1.percentile);
      return p1.sds + ratio * (p2.sds - p1.sds);
    }
  }

  return 0;
}
