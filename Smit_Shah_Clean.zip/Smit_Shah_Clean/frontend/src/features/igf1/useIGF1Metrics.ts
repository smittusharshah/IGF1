import { useQuery } from '@tanstack/react-query';
import { findReferenceTable, findReferenceRow, findTannerReferenceRow } from './referenceTables';
import { derivePercentileFromTable, deriveSDSFromTable } from './percentile';

type AgeBasedInput = {
  mode: 'age';
  sex: 'male' | 'female';
  ageBasis: 'chronological' | 'bone';
  ageYears: number;
  ageMonths: number;
  igf1Value: number;
};

type TannerBasedInput = {
  mode: 'tanner';
  sex: 'male' | 'female';
  tannerStage: 1 | 2 | 3 | 4 | 5;
  igf1Value: number;
};

type MetricsInput = AgeBasedInput | TannerBasedInput;

export interface MetricsResult {
  percentile: number;
  sds: number;
  referenceInterval: {
    lower: number;
    upper: number;
  };
}

function calculateMetrics(input: MetricsInput): MetricsResult {
  if (input.mode === 'age') {
    const table = findReferenceTable(input.sex, input.ageBasis);
    if (!table) {
      throw new Error('Reference table not found');
    }

    const row = findReferenceRow(table, input.ageYears, input.ageMonths);
    if (!row) {
      throw new Error('Reference row not found');
    }

    const percentile = derivePercentileFromTable(input.igf1Value, row);
    const sds = deriveSDSFromTable(input.igf1Value, row);

    return {
      percentile,
      sds,
      referenceInterval: {
        lower: row.p2_5 ?? row.p5,
        upper: row.p97_5 ?? row.p97 ?? row.p95 ?? row.p90,
      },
    };
  } else {
    const row = findTannerReferenceRow(input.sex, input.tannerStage);
    if (!row) {
      throw new Error('Tanner reference row not found');
    }

    const percentile = derivePercentileFromTable(input.igf1Value, row);
    const sds = deriveSDSFromTable(input.igf1Value, row);

    return {
      percentile,
      sds,
      referenceInterval: {
        lower: row.p2_5 ?? row.p5,
        upper: row.p97_5 ?? row.p97 ?? row.p95 ?? row.p90,
      },
    };
  }
}

export function useIGF1Metrics(input: MetricsInput | null) {
  return useQuery<MetricsResult>({
    queryKey: ['igf1-metrics', input],
    queryFn: () => {
      if (!input) {
        throw new Error('No input provided');
      }
      return calculateMetrics(input);
    },
    enabled: !!input,
    staleTime: Infinity,
  });
}
