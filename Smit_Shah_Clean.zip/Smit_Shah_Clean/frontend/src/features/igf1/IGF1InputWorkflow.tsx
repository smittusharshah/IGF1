import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { AlertCircle, Calendar, CalendarIcon, ChevronLeft, ChevronRight, User, Activity, FlaskConical, TrendingUp, BarChart3, Ruler } from 'lucide-react';
import { calculateAge, normalizeAge, type AgeResult, type NormalizedAge } from './age';
import { validateRequired, validateDate, validateNumeric, validateAgeYears, validateAgeMonths, validateTannerStage, type ValidationError } from './validation';
import { useIGF1Metrics } from './useIGF1Metrics';

const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAY_LABELS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

function getDaysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfMonth(year: number, month: number) {
  return new Date(year, month, 1).getDay();
}

function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function isToday(date: Date) {
  return isSameDay(date, new Date());
}

interface ModernDatePickerProps {
  label: string;
  id: string;
  value: string; // ISO format YYYY-MM-DD or __raw:...
  onChange: (iso: string) => void;
  onBlur: () => void;
  error?: string;
  fromYear?: number;
  toYear?: number;
}

function ModernDatePicker({ label, id, value, onChange, onBlur, error, fromYear = 1950, toYear = new Date().getFullYear() }: ModernDatePickerProps) {
  const [open, setOpen] = useState(false);
  const [viewYear, setViewYear] = useState(() => {
    if (value && !value.startsWith('__raw:')) {
      const d = new Date(value);
      return isNaN(d.getTime()) ? new Date().getFullYear() : d.getFullYear();
    }
    return new Date().getFullYear();
  });
  const [viewMonth, setViewMonth] = useState(() => {
    if (value && !value.startsWith('__raw:')) {
      const d = new Date(value);
      return isNaN(d.getTime()) ? new Date().getMonth() : d.getMonth();
    }
    return new Date().getMonth();
  });

  const selectedDate = value && !value.startsWith('__raw:') ? new Date(value) : null;

  // Sync view to selected date when popover opens
  useEffect(() => {
    if (open && selectedDate && !isNaN(selectedDate.getTime())) {
      setViewYear(selectedDate.getFullYear());
      setViewMonth(selectedDate.getMonth());
    }
  }, [open]);

  const toDisplayDate = (isoDate: string) => {
    if (!isoDate) return '';
    const [y, m, d] = isoDate.split('-');
    return `${d}/${m}/${y}`;
  };

  const fromDisplayDate = (displayDate: string) => {
    const cleaned = displayDate.replace(/[^0-9/]/g, '');
    const parts = cleaned.split('/');
    if (parts.length === 3 && parts[0].length === 2 && parts[1].length === 2 && parts[2].length === 4) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
    return '';
  };

  const handleDateInput = (val: string) => {
    const digits = val.replace(/[^0-9]/g, '');
    let formatted = '';
    for (let i = 0; i < digits.length && i < 8; i++) {
      if (i === 2 || i === 4) formatted += '/';
      formatted += digits[i];
    }
    const iso = fromDisplayDate(formatted);
    onChange(iso || '__raw:' + formatted);
  };

  const handleDayClick = (day: number) => {
    const month = String(viewMonth + 1).padStart(2, '0');
    const d = String(day).padStart(2, '0');
    onChange(`${viewYear}-${month}-${d}`);
    onBlur();
    setOpen(false);
  };

  const handleTodayClick = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    onChange(`${year}-${month}-${day}`);
    onBlur();
    setOpen(false);
  };

  const goToPrevMonth = () => {
    if (viewMonth === 0) {
      if (viewYear > fromYear) { setViewMonth(11); setViewYear(viewYear - 1); }
    } else {
      setViewMonth(viewMonth - 1);
    }
  };

  const goToNextMonth = () => {
    if (viewMonth === 11) {
      if (viewYear < toYear) { setViewMonth(0); setViewYear(viewYear + 1); }
    } else {
      setViewMonth(viewMonth + 1);
    }
  };

  const daysInMonth = getDaysInMonth(viewYear, viewMonth);
  const firstDay = getFirstDayOfMonth(viewYear, viewMonth);

  // Build year options
  const yearOptions: number[] = [];
  for (let y = toYear; y >= fromYear; y--) yearOptions.push(y);

  const displayValue = value.startsWith('__raw:') ? value.slice(6) : toDisplayDate(value);

  return (
    <div className="space-y-1.5">
      <Label htmlFor={id} className="input-label">
        {label} <span className="text-destructive">*</span>
      </Label>
      <Popover open={open} onOpenChange={setOpen}>
        <div className="relative">
          <Input
            id={id}
            type="text"
            inputMode="numeric"
            value={displayValue}
            onChange={(e) => handleDateInput(e.target.value)}
            onBlur={onBlur}
            placeholder="DD/MM/YYYY"
            className="flex-1 bg-white pr-10"
            maxLength={10}
          />
          <PopoverTrigger asChild>
            <button
              type="button"
              className="absolute right-1 top-1/2 -translate-y-1/2 flex items-center justify-center w-7 h-7 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
            >
              <CalendarIcon className="w-4 h-4" />
            </button>
          </PopoverTrigger>
        </div>
        <PopoverContent className="w-[320px] p-0 shadow-xl border-border/60" align="start" sideOffset={8}>
          {/* Calendar Header */}
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 px-4 py-3 rounded-t-md">
            <p className="text-xs font-medium text-indigo-100 uppercase tracking-wider">{label}</p>
            <p className="text-lg font-bold text-white mt-0.5">
              {selectedDate && !isNaN(selectedDate.getTime())
                ? selectedDate.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' })
                : 'Select a date'}
            </p>
          </div>

          {/* Month/Year Navigation */}
          <div className="flex items-center justify-between px-3 pt-3 pb-2">
            <button
              type="button"
              onClick={goToPrevMonth}
              className="flex items-center justify-center w-8 h-8 rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5">
              <select
                value={viewMonth}
                onChange={(e) => setViewMonth(parseInt(e.target.value))}
                className="appearance-none bg-muted/50 border border-border/50 rounded-md px-2.5 py-1 text-sm font-medium cursor-pointer hover:bg-muted transition-colors focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
              >
                {MONTH_NAMES.map((m, i) => (
                  <option key={i} value={i}>{m}</option>
                ))}
              </select>
              <select
                value={viewYear}
                onChange={(e) => setViewYear(parseInt(e.target.value))}
                className="appearance-none bg-muted/50 border border-border/50 rounded-md px-2.5 py-1 text-sm font-medium cursor-pointer hover:bg-muted transition-colors focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
              >
                {yearOptions.map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={goToNextMonth}
              className="flex items-center justify-center w-8 h-8 rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Day Labels */}
          <div className="grid grid-cols-7 px-3">
            {DAY_LABELS.map((d) => (
              <div key={d} className="flex items-center justify-center h-8 text-xs font-semibold text-muted-foreground uppercase">
                {d}
              </div>
            ))}
          </div>

          {/* Day Grid */}
          <div className="grid grid-cols-7 px-3 pb-2">
            {/* Empty cells before first day */}
            {Array.from({ length: firstDay }).map((_, i) => (
              <div key={`empty-${i}`} className="h-9" />
            ))}
            {/* Day cells */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const cellDate = new Date(viewYear, viewMonth, day);
              const isSelected = selectedDate && !isNaN(selectedDate.getTime()) && isSameDay(cellDate, selectedDate);
              const isTodayDate = isToday(cellDate);

              return (
                <button
                  key={day}
                  type="button"
                  onClick={() => handleDayClick(day)}
                  className={`
                    flex items-center justify-center h-9 w-full rounded-lg text-sm font-medium transition-all
                    ${isSelected
                      ? 'bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-200/50 scale-105'
                      : isTodayDate
                        ? 'bg-indigo-50 text-indigo-700 font-bold ring-1 ring-indigo-200'
                        : 'text-foreground hover:bg-muted/80 hover:text-primary'
                    }
                  `}
                >
                  {day}
                </button>
              );
            })}
          </div>

          {/* Footer */}
          <div className="border-t border-border/40 px-3 py-2.5 flex items-center justify-between bg-muted/20 rounded-b-md">
            <button
              type="button"
              onClick={handleTodayClick}
              className="text-xs font-semibold text-primary hover:text-primary/80 hover:underline transition-colors"
            >
              Today
            </button>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Close
            </button>
          </div>
        </PopoverContent>
      </Popover>
      {error && (
        <p className="text-sm text-destructive flex items-center gap-1">
          <AlertCircle className="w-3.5 h-3.5" />
          {error}
        </p>
      )}
    </div>
  );
}

type Sex = 'male' | 'female' | '';
type AgeBasis = 'chronological' | 'bone' | '';
type AgeEntryMode = 'dates' | 'direct';
type CalculationMode = 'age' | 'tanner';
type TannerStage = '' | '1' | '2' | '3' | '4' | '5';

export function IGF1InputWorkflow() {
  const [calculationMode, setCalculationMode] = useState<CalculationMode>('age');
  const [sex, setSex] = useState<Sex>('');
  const [ageBasis, setAgeBasis] = useState<AgeBasis>('');
  const [ageEntryMode, setAgeEntryMode] = useState<AgeEntryMode>('direct');
  const [tannerStage, setTannerStage] = useState<TannerStage>('');

  // Date-based inputs
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [dateOfTesting, setDateOfTesting] = useState('');
  const [ageResult, setAgeResult] = useState<AgeResult | null>(null);

  // Direct age inputs - initialize months to "0"
  const [ageYears, setAgeYears] = useState('');
  const [ageMonths, setAgeMonths] = useState('0');

  // IGF-1 value
  const [igf1Value, setIgf1Value] = useState('');

  const [errors, setErrors] = useState<Record<string, ValidationError>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  // Initialize date of testing to today
  useEffect(() => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    setDateOfTesting(`${year}-${month}-${day}`);
  }, []);

  // Reset months to "0" when switching to direct mode
  useEffect(() => {
    if (ageEntryMode === 'direct' && ageMonths === '') {
      setAgeMonths('0');
    }
  }, [ageEntryMode, ageMonths]);

  // Calculate age whenever dates change (only in dates mode)
  useEffect(() => {
    if (ageEntryMode === 'dates' && dateOfBirth && dateOfTesting && !dateOfBirth.startsWith('__raw:') && !dateOfTesting.startsWith('__raw:')) {
      const result = calculateAge(dateOfBirth, dateOfTesting);
      setAgeResult(result);
    } else {
      setAgeResult(null);
    }
  }, [dateOfBirth, dateOfTesting, ageEntryMode]);

  // Validate fields
  useEffect(() => {
    const newErrors: Record<string, ValidationError> = {};

    if (touched.sex) {
      const sexError = validateRequired(sex, 'Sex');
      if (sexError) newErrors.sex = sexError;
    }

    if (calculationMode === 'age') {
      if (touched.ageBasis) {
        const ageBasisError = validateRequired(ageBasis, 'Age Type');
        if (ageBasisError) newErrors.ageBasis = ageBasisError;
      }

      if (ageEntryMode === 'dates') {
        if (touched.dateOfBirth) {
          const dobError = validateDate(dateOfBirth, 'Date of birth');
          if (dobError) newErrors.dateOfBirth = dobError;
        }

        if (touched.dateOfTesting) {
          const dotError = validateDate(dateOfTesting, 'Date of testing');
          if (dotError) newErrors.dateOfTesting = dotError;
        }
      } else {
        if (touched.ageYears) {
          const yearsError = validateAgeYears(ageYears);
          if (yearsError) newErrors.ageYears = yearsError;
        }

        if (touched.ageMonths) {
          // Treat empty as "0" for validation
          const monthsValue = ageMonths.trim() === '' ? '0' : ageMonths;
          const monthsError = validateAgeMonths(monthsValue);
          if (monthsError) newErrors.ageMonths = monthsError;
        }
      }
    } else {
      // Tanner stage mode
      if (touched.tannerStage) {
        const tannerError = validateTannerStage(tannerStage);
        if (tannerError) newErrors.tannerStage = tannerError;
      }
    }

    if (touched.igf1Value) {
      const igf1Error = validateNumeric(igf1Value, 'IGF-1');
      if (igf1Error) newErrors.igf1Value = igf1Error;
    }

    setErrors(newErrors);
  }, [sex, ageBasis, dateOfBirth, dateOfTesting, ageYears, ageMonths, tannerStage, igf1Value, touched, ageEntryMode, calculationMode]);

  const handleBlur = (field: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
  };

  // Handle months blur - coerce empty to "0"
  const handleMonthsBlur = () => {
    if (ageMonths.trim() === '') {
      setAgeMonths('0');
    }
    handleBlur('ageMonths');
  };

  // Compute normalized age for calculations
  const getNormalizedAge = (): NormalizedAge | null => {
    if (calculationMode !== 'age') return null;

    if (ageEntryMode === 'dates') {
      if (ageResult && !ageResult.error) {
        return { years: ageResult.years, months: ageResult.months };
      }
    } else {
      const years = parseInt(ageYears, 10);
      // Treat empty months as 0
      const monthsValue = ageMonths.trim() === '' ? '0' : ageMonths;
      const months = parseInt(monthsValue, 10);
      if (!isNaN(years) && !isNaN(months)) {
        return normalizeAge(years, months);
      }
    }
    return null;
  };

  const normalizedAge = getNormalizedAge();
  const igf1Numeric = parseFloat(igf1Value);

  // Check if all inputs are valid for calculation
  const canCalculate = (() => {
    if (sex === '' || isNaN(igf1Numeric) || Object.keys(errors).length > 0) {
      return false;
    }

    if (calculationMode === 'age') {
      return ageBasis !== '' && normalizedAge !== null;
    } else {
      return tannerStage !== '';
    }
  })();

  // Prepare input for the calculation hook
  const metricsInput = canCalculate
    ? calculationMode === 'age'
      ? {
          mode: 'age' as const,
          sex: sex as 'male' | 'female',
          ageBasis: ageBasis as 'chronological' | 'bone',
          ageYears: normalizedAge!.years,
          ageMonths: normalizedAge!.months,
          igf1Value: igf1Numeric,
        }
      : {
          mode: 'tanner' as const,
          sex: sex as 'male' | 'female',
          tannerStage: parseInt(tannerStage, 10) as 1 | 2 | 3 | 4 | 5,
          igf1Value: igf1Numeric,
        }
    : null;

  // Use the calculation hook
  const { data: metricsResult, isLoading, error: metricsError } = useIGF1Metrics(metricsInput);

  return (
    <div className="space-y-6">
      {/* Patient Information Card */}
      <Card className="shadow-md shadow-indigo-100/50 border-border/50 overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-indigo-50/80 via-purple-50/50 to-transparent pb-5 border-b border-border/30">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 shadow-sm">
              <User className="w-4 h-4 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg font-semibold">Patient Information</CardTitle>
              <p className="text-sm text-muted-foreground mt-0.5">
                Enter patient details to calculate IGF-1 metrics
              </p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          {/* Calculation Mode Selection */}
          <div className="input-section">
            <Label className="input-label">
              Calculation Method <span className="text-destructive">*</span>
            </Label>
            <div className="grid grid-cols-2 gap-3 mt-2">
              <button
                type="button"
                onClick={() => setCalculationMode('age')}
                className={`relative flex items-center gap-3 rounded-lg border-2 px-4 py-3 text-left text-sm font-medium transition-all ${
                  calculationMode === 'age'
                    ? 'border-primary bg-primary/5 text-primary shadow-sm'
                    : 'border-border/60 bg-white hover:border-border hover:bg-muted/30 text-muted-foreground'
                }`}
              >
                <Calendar className="w-4 h-4 shrink-0" />
                <span>Age-based</span>
              </button>
              <button
                type="button"
                onClick={() => setCalculationMode('tanner')}
                className={`relative flex items-center gap-3 rounded-lg border-2 px-4 py-3 text-left text-sm font-medium transition-all ${
                  calculationMode === 'tanner'
                    ? 'border-primary bg-primary/5 text-primary shadow-sm'
                    : 'border-border/60 bg-white hover:border-border hover:bg-muted/30 text-muted-foreground'
                }`}
              >
                <Activity className="w-4 h-4 shrink-0" />
                <span>Tanner stage</span>
              </button>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-border/40" />

          {/* Sex Selection */}
          <div className="input-section">
            <Label className="input-label flex items-center gap-2">
              <User className="w-3.5 h-3.5 text-primary" />
              Sex <span className="text-destructive">*</span>
            </Label>
            <div className="grid grid-cols-2 gap-3 mt-2">
              <button
                type="button"
                onClick={() => { setSex('male'); handleBlur('sex'); }}
                className={`rounded-lg border-2 px-4 py-2.5 text-sm font-medium transition-all ${
                  sex === 'male'
                    ? 'border-blue-500 bg-blue-50 text-blue-700 shadow-sm'
                    : 'border-border/60 bg-white hover:border-border hover:bg-muted/30 text-muted-foreground'
                }`}
              >
                Male
              </button>
              <button
                type="button"
                onClick={() => { setSex('female'); handleBlur('sex'); }}
                className={`rounded-lg border-2 px-4 py-2.5 text-sm font-medium transition-all ${
                  sex === 'female'
                    ? 'border-pink-500 bg-pink-50 text-pink-700 shadow-sm'
                    : 'border-border/60 bg-white hover:border-border hover:bg-muted/30 text-muted-foreground'
                }`}
              >
                Female
              </button>
            </div>
            {errors.sex && (
              <p className="text-sm text-destructive mt-1.5 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {errors.sex.message}
              </p>
            )}
          </div>

          {/* Age-based inputs */}
          {calculationMode === 'age' && (
            <>
              {/* Age Type Selection */}
              <div className="input-section">
                <Label className="input-label flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5 text-primary" />
                  Age Type <span className="text-destructive">*</span>
                </Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  <button
                    type="button"
                    onClick={() => { setAgeBasis('chronological'); handleBlur('ageBasis'); }}
                    className={`relative flex items-center gap-3 rounded-lg border-2 px-4 py-3 text-left text-sm font-medium transition-all ${
                      ageBasis === 'chronological'
                        ? 'border-primary bg-primary/5 text-primary shadow-sm'
                        : 'border-border/60 bg-white hover:border-border hover:bg-muted/30 text-muted-foreground'
                    }`}
                  >
                    <Calendar className="w-4 h-4 shrink-0" />
                    <span>Chronological Age</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => { setAgeBasis('bone'); handleBlur('ageBasis'); }}
                    className={`relative flex items-center gap-3 rounded-lg border-2 px-4 py-3 text-left text-sm font-medium transition-all ${
                      ageBasis === 'bone'
                        ? 'border-primary bg-primary/5 text-primary shadow-sm'
                        : 'border-border/60 bg-white hover:border-border hover:bg-muted/30 text-muted-foreground'
                    }`}
                  >
                    <Ruler className="w-4 h-4 shrink-0" />
                    <span>Bone Age (Greulich and Pyle)</span>
                  </button>
                </div>
                {errors.ageBasis && (
                  <p className="text-sm text-destructive mt-1.5 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errors.ageBasis.message}
                  </p>
                )}
              </div>

              {/* Divider */}
              <div className="border-t border-border/40" />

              {/* Age Entry Mode Selection */}
              <div className="input-section">
                <Label className="input-label">
                  Age Entry Method <span className="text-destructive">*</span>
                </Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  <button
                    type="button"
                    onClick={() => setAgeEntryMode('direct')}
                    className={`rounded-lg border-2 px-4 py-2.5 text-sm font-medium transition-all ${
                      ageEntryMode === 'direct'
                        ? 'border-primary bg-primary/5 text-primary shadow-sm'
                        : 'border-border/60 bg-white hover:border-border hover:bg-muted/30 text-muted-foreground'
                    }`}
                  >
                    Enter age directly
                  </button>
                  <button
                    type="button"
                    onClick={() => setAgeEntryMode('dates')}
                    className={`rounded-lg border-2 px-4 py-2.5 text-sm font-medium transition-all ${
                      ageEntryMode === 'dates'
                        ? 'border-primary bg-primary/5 text-primary shadow-sm'
                        : 'border-border/60 bg-white hover:border-border hover:bg-muted/30 text-muted-foreground'
                    }`}
                  >
                    Enter dates
                  </button>
                </div>
              </div>

              {/* Date-based inputs */}
              {ageEntryMode === 'dates' && (
                <div className="space-y-4 rounded-lg bg-muted/30 border border-border/30 p-4">
                  <ModernDatePicker
                    label="Date of Birth"
                    id="dateOfBirth"
                    value={dateOfBirth}
                    onChange={setDateOfBirth}
                    onBlur={() => handleBlur('dateOfBirth')}
                    error={errors.dateOfBirth?.message}
                  />

                  <ModernDatePicker
                    label="Date of Testing"
                    id="dateOfTesting"
                    value={dateOfTesting}
                    onChange={setDateOfTesting}
                    onBlur={() => handleBlur('dateOfTesting')}
                    error={errors.dateOfTesting?.message}
                  />

                  {/* Age Display or Error */}
                  {ageResult && (
                    <div>
                      {ageResult.error ? (
                        <Alert variant="destructive">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription>{ageResult.error}</AlertDescription>
                        </Alert>
                      ) : (
                        <div className="bg-gradient-to-r from-indigo-50 to-blue-50 border border-indigo-200/50 rounded-lg p-4 flex items-center gap-3">
                          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-indigo-100">
                            <Calendar className="w-5 h-5 text-indigo-600" />
                          </div>
                          <div>
                            <p className="text-xs font-medium text-indigo-500 uppercase tracking-wider">
                              Calculated Age
                            </p>
                            <p className="text-xl font-bold text-indigo-900">
                              {ageResult.years} {ageResult.years === 1 ? 'year' : 'years'}{' '}
                              {ageResult.months} {ageResult.months === 1 ? 'month' : 'months'}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Direct age inputs */}
              {ageEntryMode === 'direct' && (
                <div className="grid grid-cols-2 gap-4 rounded-lg bg-muted/30 border border-border/30 p-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="ageYears" className="input-label">
                      Years <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="ageYears"
                      type="number"
                      min="0"
                      step="1"
                      value={ageYears}
                      onChange={(e) => setAgeYears(e.target.value)}
                      onBlur={() => handleBlur('ageYears')}
                      placeholder="0"
                      className="w-full bg-white"
                    />
                    {errors.ageYears && (
                      <p className="text-sm text-destructive flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {errors.ageYears.message}
                      </p>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="ageMonths" className="input-label">
                      Months
                    </Label>
                    <Input
                      id="ageMonths"
                      type="number"
                      min="0"
                      max="11"
                      step="1"
                      value={ageMonths}
                      onChange={(e) => setAgeMonths(e.target.value)}
                      onBlur={handleMonthsBlur}
                      placeholder="0"
                      className="w-full bg-white"
                    />
                    {errors.ageMonths && (
                      <p className="text-sm text-destructive flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {errors.ageMonths.message}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </>
          )}

          {/* Tanner stage input */}
          {calculationMode === 'tanner' && (
            <div className="input-section">
              <Label htmlFor="tannerStage" className="input-label flex items-center gap-2">
                <Activity className="w-3.5 h-3.5 text-primary" />
                Tanner Stage <span className="text-destructive">*</span>
              </Label>
              <Select
                value={tannerStage}
                onValueChange={(value) => setTannerStage(value as TannerStage)}
              >
                <SelectTrigger
                  id="tannerStage"
                  className="w-full mt-2"
                  onBlur={() => handleBlur('tannerStage')}
                >
                  <SelectValue placeholder="Select Tanner stage" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Stage I — Prepubertal</SelectItem>
                  <SelectItem value="2">Stage II</SelectItem>
                  <SelectItem value="3">Stage III</SelectItem>
                  <SelectItem value="4">Stage IV</SelectItem>
                  <SelectItem value="5">Stage V — Adult</SelectItem>
                </SelectContent>
              </Select>
              {errors.tannerStage && (
                <p className="text-sm text-destructive mt-1.5 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {errors.tannerStage.message}
                </p>
              )}
            </div>
          )}

          {/* Divider */}
          <div className="border-t border-border/40" />

          {/* IGF-1 Value Input */}
          <div className="input-section">
            <Label htmlFor="igf1Value" className="input-label flex items-center gap-2">
              <FlaskConical className="w-3.5 h-3.5 text-primary" />
              IGF-1 Value <span className="text-destructive">*</span>
            </Label>
            <div className="relative mt-2">
              <Input
                id="igf1Value"
                type="number"
                min="0"
                step="0.1"
                value={igf1Value}
                onChange={(e) => setIgf1Value(e.target.value)}
                onBlur={() => handleBlur('igf1Value')}
                placeholder="Enter IGF-1 value"
                className="w-full pr-16"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-muted-foreground bg-muted/60 px-2 py-0.5 rounded">
                ng/mL
              </span>
            </div>
            {errors.igf1Value && (
              <p className="text-sm text-destructive mt-1.5 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {errors.igf1Value.message}
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Results Section */}
      {canCalculate && (
        <Card className="shadow-md shadow-indigo-100/50 border-border/50 overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-emerald-50/80 via-teal-50/50 to-transparent pb-5 border-b border-border/30">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 shadow-sm">
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold">Results</CardTitle>
                <p className="text-sm text-muted-foreground mt-0.5">
                  IGF-1 metrics calculated from patient data
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            {isLoading && (
              <div className="flex items-center justify-center py-12">
                <div className="flex flex-col items-center gap-3">
                  <div className="animate-spin rounded-full h-10 w-10 border-2 border-primary border-t-transparent"></div>
                  <p className="text-sm text-muted-foreground">Calculating...</p>
                </div>
              </div>
            )}

            {metricsError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Error calculating metrics. Please check your inputs and try again.
                </AlertDescription>
              </Alert>
            )}

            {metricsResult && !isLoading && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  {/* Percentile */}
                  <div className="result-box-blue">
                    <div className="flex items-center justify-center gap-2 mb-3">
                      <TrendingUp className="w-4 h-4 text-blue-500" />
                      <p className="text-xs font-semibold text-blue-600 uppercase tracking-wider">Percentile</p>
                    </div>
                    <p className="text-4xl font-bold text-blue-900 tabular-nums">
                      {metricsResult.percentile.toFixed(1)}
                    </p>
                  </div>

                  {/* SDS */}
                  <div className="result-box-green">
                    <div className="flex items-center justify-center gap-2 mb-3">
                      <BarChart3 className="w-4 h-4 text-emerald-500" />
                      <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">SDS</p>
                    </div>
                    <p className="text-4xl font-bold text-emerald-900 tabular-nums">
                      {metricsResult.sds >= 0 ? '+' : ''}
                      {metricsResult.sds.toFixed(2)}
                    </p>
                  </div>

                  {/* Reference Interval */}
                  <div className="result-box-purple">
                    <div className="flex items-center justify-center gap-2 mb-3">
                      <Ruler className="w-4 h-4 text-violet-500" />
                      <p className="text-xs font-semibold text-violet-600 uppercase tracking-wider">Reference Interval</p>
                    </div>
                    <p className="text-2xl font-bold text-violet-900 tabular-nums">
                      {metricsResult.referenceInterval.lower}–{metricsResult.referenceInterval.upper}
                    </p>
                    <p className="text-xs text-violet-500 font-medium mt-1">ng/mL</p>
                  </div>
                </div>

              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
