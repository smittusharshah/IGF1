export interface AgeResult {
  years: number;
  months: number;
  error?: string;
}

export interface NormalizedAge {
  years: number;
  months: number;
}

/**
 * Calculate age in years and months between two dates
 * @param birthDateStr - Date of birth in YYYY-MM-DD format
 * @param testDateStr - Date of testing in YYYY-MM-DD format
 * @returns AgeResult with years, months, and optional error message
 */
export function calculateAge(birthDateStr: string, testDateStr: string): AgeResult {
  const birthDate = new Date(birthDateStr);
  const testDate = new Date(testDateStr);

  // Validate dates
  if (isNaN(birthDate.getTime()) || isNaN(testDate.getTime())) {
    return {
      years: 0,
      months: 0,
      error: 'Invalid date format',
    };
  }

  // Check if test date is before birth date
  if (testDate < birthDate) {
    return {
      years: 0,
      months: 0,
      error: 'Date of testing cannot be earlier than date of birth',
    };
  }

  // Calculate years
  let years = testDate.getFullYear() - birthDate.getFullYear();
  let months = testDate.getMonth() - birthDate.getMonth();

  // Adjust if months is negative
  if (months < 0) {
    years--;
    months += 12;
  }

  // Adjust if day of month hasn't been reached yet
  if (testDate.getDate() < birthDate.getDate()) {
    months--;
    if (months < 0) {
      years--;
      months += 12;
    }
  }

  return {
    years,
    months,
  };
}

/**
 * Normalize age values to ensure months is 0-11
 * @param years - Age in years
 * @param months - Age in months
 * @returns Normalized age with months clamped to 0-11
 */
export function normalizeAge(years: number, months: number): NormalizedAge {
  // Clamp months to 0-11 range
  const normalizedMonths = Math.max(0, Math.min(11, months));
  
  return {
    years: Math.max(0, years),
    months: normalizedMonths,
  };
}
