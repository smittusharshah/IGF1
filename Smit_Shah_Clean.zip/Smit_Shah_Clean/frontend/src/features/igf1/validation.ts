export interface ValidationError {
  field: string;
  message: string;
}

/**
 * Validate that a required field has a value
 */
export function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return {
      field: fieldName,
      message: `${fieldName} is required`,
    };
  }
  return null;
}

/**
 * Validate that a date string is valid and not empty
 */
export function validateDate(dateStr: string, fieldName: string): ValidationError | null {
  if (!dateStr || dateStr.trim() === '') {
    return {
      field: fieldName,
      message: `${fieldName} is required`,
    };
  }

  const date = new Date(dateStr);
  if (isNaN(date.getTime())) {
    return {
      field: fieldName,
      message: `${fieldName} must be a valid date`,
    };
  }

  return null;
}

/**
 * Validate that a numeric field has a valid number
 */
export function validateNumeric(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return {
      field: fieldName,
      message: `${fieldName} is required`,
    };
  }

  const num = parseFloat(value);
  if (isNaN(num)) {
    return {
      field: fieldName,
      message: `${fieldName} must be a valid number`,
    };
  }

  if (num < 0) {
    return {
      field: fieldName,
      message: `${fieldName} must be a positive number`,
    };
  }

  return null;
}

/**
 * Validate age years input
 */
export function validateAgeYears(value: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return {
      field: 'Years',
      message: 'Years is required',
    };
  }

  const num = parseInt(value, 10);
  if (isNaN(num)) {
    return {
      field: 'Years',
      message: 'Years must be a valid integer',
    };
  }

  if (num < 0) {
    return {
      field: 'Years',
      message: 'Years must be a non-negative integer',
    };
  }

  return null;
}

/**
 * Validate age months input - treats empty as valid (defaults to 0)
 */
export function validateAgeMonths(value: string): ValidationError | null {
  // Allow empty value (will be treated as 0)
  if (!value || value.trim() === '') {
    return null;
  }

  const num = parseInt(value, 10);
  if (isNaN(num)) {
    return {
      field: 'Months',
      message: 'Months must be a valid integer',
    };
  }

  if (num < 0 || num > 11) {
    return {
      field: 'Months',
      message: 'Months must be an integer from 0 to 11',
    };
  }

  return null;
}

/**
 * Validate Tanner stage selection
 */
export function validateTannerStage(value: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return {
      field: 'Tanner stage',
      message: 'Tanner stage is required',
    };
  }

  const num = parseInt(value, 10);
  if (isNaN(num) || num < 1 || num > 5) {
    return {
      field: 'Tanner stage',
      message: 'Tanner stage must be between I and V',
    };
  }

  return null;
}
