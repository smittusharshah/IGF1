/**
 * Developer-only verification module that runs deterministic checks for six known test cases
 * including Table 1 (chronological age), Table 2 (bone age), and Table 3 (Tanner stage)
 * exact-match scenarios; calls the same table lookup and percentile derivation logic used by the app.
 */

import { findReferenceTable, findReferenceRow, findTannerReferenceRow } from './referenceTables';
import { derivePercentileFromTable, deriveSDSFromTable } from './percentile';

interface TestCase {
  description: string;
  sex: 'male' | 'female';
  mode: 'age' | 'tanner';
  ageBasis?: 'chronological' | 'bone';
  ageYears?: number;
  ageMonths?: number;
  tannerStage?: 1 | 2 | 3 | 4 | 5;
  igf1Value: number;
  expectedPercentile: number;
  expectedSDSRange?: { min: number; max: number };
}

const testCases: TestCase[] = [
  // Table 1 (Chronological Age) - Male
  {
    description: 'Male, 10y 0m, chronological age, IGF-1=166.1 (p50)',
    sex: 'male',
    mode: 'age',
    ageBasis: 'chronological',
    ageYears: 10,
    ageMonths: 0,
    igf1Value: 166.1,
    expectedPercentile: 50,
    expectedSDSRange: { min: -0.05, max: 0.05 },
  },
  // Table 1 (Chronological Age) - Female
  {
    description: 'Female, 12y 0m, chronological age, IGF-1=313.0 (p50)',
    sex: 'female',
    mode: 'age',
    ageBasis: 'chronological',
    ageYears: 12,
    ageMonths: 0,
    igf1Value: 313.0,
    expectedPercentile: 50,
    expectedSDSRange: { min: -0.05, max: 0.05 },
  },
  // Table 2 (Bone Age) - Male
  {
    description: 'Male, 13y 0m, bone age, IGF-1=252.3 (p50)',
    sex: 'male',
    mode: 'age',
    ageBasis: 'bone',
    ageYears: 13,
    ageMonths: 0,
    igf1Value: 252.3,
    expectedPercentile: 50,
    expectedSDSRange: { min: -0.05, max: 0.05 },
  },
  // Table 2 (Bone Age) - Female
  {
    description: 'Female, 14y 0m, bone age, IGF-1=350.2 (p50)',
    sex: 'female',
    mode: 'age',
    ageBasis: 'bone',
    ageYears: 14,
    ageMonths: 0,
    igf1Value: 350.2,
    expectedPercentile: 50,
    expectedSDSRange: { min: -0.05, max: 0.05 },
  },
  // Table 3 (Tanner Stage) - Male
  {
    description: 'Male, Tanner III, IGF-1=304.8 (p50)',
    sex: 'male',
    mode: 'tanner',
    tannerStage: 3,
    igf1Value: 304.8,
    expectedPercentile: 50,
    expectedSDSRange: { min: -0.05, max: 0.05 },
  },
  // Table 3 (Tanner Stage) - Female
  {
    description: 'Female, Tanner IV, IGF-1=345.0 (p50)',
    sex: 'female',
    mode: 'tanner',
    tannerStage: 4,
    igf1Value: 345.0,
    expectedPercentile: 50,
    expectedSDSRange: { min: -0.05, max: 0.05 },
  },
];

export function runVerificationChecks(): void {
  console.group('🔬 IGF-1 Calculation Verification');

  let passCount = 0;
  let failCount = 0;

  for (const testCase of testCases) {
    try {
      let percentile: number;
      let sds: number;

      if (testCase.mode === 'age') {
        const table = findReferenceTable(testCase.sex, testCase.ageBasis!);
        if (!table) {
          throw new Error('Reference table not found');
        }

        const row = findReferenceRow(table, testCase.ageYears!, testCase.ageMonths!);
        if (!row) {
          throw new Error('Reference row not found');
        }

        percentile = derivePercentileFromTable(testCase.igf1Value, row);
        sds = deriveSDSFromTable(testCase.igf1Value, row);
      } else {
        const row = findTannerReferenceRow(testCase.sex, testCase.tannerStage!);
        if (!row) {
          throw new Error('Tanner reference row not found');
        }

        percentile = derivePercentileFromTable(testCase.igf1Value, row);
        sds = deriveSDSFromTable(testCase.igf1Value, row);
      }

      const percentileMatch = Math.abs(percentile - testCase.expectedPercentile) < 0.1;
      const sdsMatch = testCase.expectedSDSRange
        ? sds >= testCase.expectedSDSRange.min && sds <= testCase.expectedSDSRange.max
        : true;

      if (percentileMatch && sdsMatch) {
        console.log(`✅ ${testCase.description}`);
        console.log(`   Percentile: ${percentile.toFixed(2)} (expected ${testCase.expectedPercentile})`);
        console.log(`   SDS: ${sds.toFixed(2)}${testCase.expectedSDSRange ? ` (expected ${testCase.expectedSDSRange.min} to ${testCase.expectedSDSRange.max})` : ''}`);
        passCount++;
      } else {
        console.error(`❌ ${testCase.description}`);
        console.error(`   Percentile: ${percentile.toFixed(2)} (expected ${testCase.expectedPercentile}) ${percentileMatch ? '✓' : '✗'}`);
        console.error(`   SDS: ${sds.toFixed(2)}${testCase.expectedSDSRange ? ` (expected ${testCase.expectedSDSRange.min} to ${testCase.expectedSDSRange.max})` : ''} ${sdsMatch ? '✓' : '✗'}`);
        failCount++;
      }
    } catch (error) {
      console.error(`❌ ${testCase.description}`);
      console.error(`   Error: ${error instanceof Error ? error.message : String(error)}`);
      failCount++;
    }
  }

  console.log(`\n📊 Results: ${passCount} passed, ${failCount} failed`);
  console.groupEnd();
}
