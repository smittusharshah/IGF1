/**
 * Centralized mapping of calculation categories to PDF table numbers
 * Source: Normative Data IGF-1 ECLIA Indian children and adolescents 2024
 */

export interface DataSourceEntry {
  category: string;
  tableNumber: string;
  description: string;
}

export const DATA_SOURCE_MAPPING: DataSourceEntry[] = [
  {
    category: 'Male Chronological Age',
    tableNumber: 'Table 1',
    description: 'IGF-1 reference values for males based on chronological age',
  },
  {
    category: 'Female Chronological Age',
    tableNumber: 'Table 1',
    description: 'IGF-1 reference values for females based on chronological age',
  },
  {
    category: 'Male Bone Age',
    tableNumber: 'Table 2',
    description: 'IGF-1 reference values for males based on bone age',
  },
  {
    category: 'Female Bone Age',
    tableNumber: 'Table 2',
    description: 'IGF-1 reference values for females based on bone age',
  },
  {
    category: 'Tanner Stage',
    tableNumber: 'Table 3',
    description: 'IGF-1 reference values based on Tanner stage (both sexes)',
  },
];

/**
 * Get the table number for a specific category
 */
export function getTableNumber(category: string): string | null {
  const entry = DATA_SOURCE_MAPPING.find((e) => e.category === category);
  return entry ? entry.tableNumber : null;
}
