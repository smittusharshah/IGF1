/**
 * IGF-1 Reference Tables
 * Extracted from: Normative Data IGF-1 ECLIA Indian children and adolescents 2024
 * Source: https://drive.google.com/file/d/1S68zQYqtl0d9W-HFVCPrcIJ3u67i35Ao/view?usp=drivesdk
 * 
 * Tables are organized by:
 * - Sex: Male / Female
 * - Age Basis: Chronological Age / Bone Age
 * - Tanner Stage: I, II, III, IV, V
 */

import { DATA_SOURCE_MAPPING } from './dataSourceMapping';

export interface ReferenceRow {
  ageYears: number;
  ageMonths: number;
  mean: number;
  sd: number;
  p2_5?: number;
  p5: number;
  p10: number;
  p25: number;
  p50: number;
  p75: number;
  p90: number;
  p95?: number;
  p97?: number;
  p97_5?: number;
}

export interface ReferenceTable {
  sex: 'male' | 'female';
  ageBasis: 'chronological' | 'bone';
  rows: ReferenceRow[];
  sourceTable?: string;
}

export interface TannerReferenceRow {
  sex: 'male' | 'female';
  tannerStage: 1 | 2 | 3 | 4 | 5;
  mean: number;
  sd: number;
  p2_5?: number;
  p5: number;
  p10: number;
  p25: number;
  p50: number;
  p75: number;
  p90: number;
  p95?: number;
  p97?: number;
  p97_5?: number;
}

// Male Chronological Age (Table 1) - User-verified data
const maleChronologicalAge: ReferenceRow[] = [
  { ageYears: 5, ageMonths: 0, mean: 96.9, sd: 0, p2_5: 31.0, p5: 39.4, p10: 50.3, p25: 70.9, p50: 96.9, p75: 127.2, p90: 159.7, p95: 181.8, p97_5: 202.5 },
  { ageYears: 6, ageMonths: 0, mean: 111.9, sd: 0, p2_5: 39.0, p5: 48.1, p10: 59.9, p25: 82.6, p50: 111.9, p75: 147.0, p90: 185.7, p95: 212.5, p97_5: 238.0 },
  { ageYears: 7, ageMonths: 0, mean: 125.0, sd: 0, p2_5: 46.2, p5: 55.9, p10: 68.6, p25: 93.0, p50: 125.0, p75: 164.0, p90: 207.6, p95: 238.3, p97_5: 267.9 },
  { ageYears: 8, ageMonths: 0, mean: 135.7, sd: 0, p2_5: 52.3, p5: 62.6, p10: 75.9, p25: 101.8, p50: 135.7, p75: 177.3, p90: 224.4, p95: 257.6, p97_5: 289.9 },
  { ageYears: 9, ageMonths: 0, mean: 147.9, sd: 0, p2_5: 58.7, p5: 69.8, p10: 84.1, p25: 111.8, p50: 147.9, p75: 192.2, p90: 242.2, p95: 277.5, p97_5: 311.8 },
  { ageYears: 10, ageMonths: 0, mean: 166.1, sd: 0, p2_5: 67.3, p5: 79.7, p10: 95.7, p25: 126.4, p50: 166.1, p75: 214.1, p90: 267.9, p95: 305.6, p97_5: 342.0 },
  { ageYears: 11, ageMonths: 0, mean: 193.3, sd: 0, p2_5: 79.2, p5: 93.9, p10: 112.6, p25: 148.1, p50: 193.3, p75: 247.0, p90: 306.0, p95: 346.8, p97_5: 385.8 },
  { ageYears: 12, ageMonths: 0, mean: 232.1, sd: 0, p2_5: 95.4, p5: 113.6, p10: 136.5, p25: 179.1, p50: 232.1, p75: 293.5, p90: 359.4, p95: 404.2, p97_5: 446.3 },
  { ageYears: 13, ageMonths: 0, mean: 275.8, sd: 0, p2_5: 112.9, p5: 135.5, p10: 163.5, p25: 214.4, p50: 275.8, p75: 344.8, p90: 416.8, p95: 464.6, p97_5: 508.9 },
  { ageYears: 14, ageMonths: 0, mean: 308.3, sd: 0, p2_5: 124.5, p5: 151.3, p10: 183.9, p25: 241.4, p50: 308.3, p75: 380.9, p90: 454.2, p95: 501.7, p97_5: 545.1 },
  { ageYears: 15, ageMonths: 0, mean: 318.9, sd: 0, p2_5: 125.8, p5: 155.8, p10: 191.3, p25: 251.6, p50: 318.9, p75: 389.0, p90: 457.6, p95: 500.9, p97_5: 539.8 },
  { ageYears: 16, ageMonths: 0, mean: 311.5, sd: 0, p2_5: 119.6, p5: 151.5, p10: 188.1, p25: 247.8, p50: 311.5, p75: 375.3, p90: 435.4, p95: 472.6, p97_5: 505.4 },
  { ageYears: 17, ageMonths: 0, mean: 292.8, sd: 0, p2_5: 110.4, p5: 142.5, p10: 178.6, p25: 235.2, p50: 292.8, p75: 348.2, p90: 398.8, p95: 429.3, p97_5: 455.9 },
  { ageYears: 18, ageMonths: 0, mean: 267.2, sd: 0, p2_5: 101.4, p5: 131.9, p10: 165.6, p25: 217.1, p50: 267.2, p75: 313.6, p90: 354.7, p95: 379.0, p97_5: 399.9 },
];

// Female Chronological Age (Table 1) - User-verified data
const femaleChronologicalAge: ReferenceRow[] = [
  { ageYears: 5, ageMonths: 0, mean: 122.6, sd: 0, p2_5: 46.3, p5: 54.2, p10: 65.0, p25: 87.8, p50: 122.6, p75: 168.5, p90: 219.2, p95: 254.2, p97_5: 287.7 },
  { ageYears: 6, ageMonths: 0, mean: 132.3, sd: 0, p2_5: 48.5, p5: 57.5, p10: 69.6, p25: 94.9, p50: 132.3, p75: 179.9, p90: 230.6, p95: 264.6, p97_5: 296.5 },
  { ageYears: 7, ageMonths: 0, mean: 142.5, sd: 0, p2_5: 50.9, p5: 61.1, p10: 74.7, p25: 102.5, p50: 142.5, p75: 191.8, p90: 242.6, p95: 275.8, p97_5: 306.4 },
  { ageYears: 8, ageMonths: 0, mean: 157.4, sd: 0, p2_5: 55.0, p5: 66.8, p10: 82.3, p25: 113.6, p50: 157.4, p75: 209.7, p90: 262.0, p95: 295.5, p97_5: 325.9 },
  { ageYears: 9, ageMonths: 0, mean: 185.0, sd: 0, p2_5: 63.5, p5: 78.0, p10: 96.9, p25: 134.2, p50: 185.0, p75: 244.0, p90: 301.5, p95: 337.6, p97_5: 370.1 },
  { ageYears: 10, ageMonths: 0, mean: 230.6, sd: 0, p2_5: 78.1, p5: 97.0, p10: 121.2, p25: 168.2, p50: 230.6, p75: 301.0, p90: 368.1, p95: 409.6, p97_5: 446.5 },
  { ageYears: 11, ageMonths: 0, mean: 280.0, sd: 0, p2_5: 94.3, p5: 118.1, p10: 148.3, p25: 205.7, p50: 280.0, p75: 362.0, p90: 438.3, p95: 485.0, p97_5: 526.0 },
  { ageYears: 12, ageMonths: 0, mean: 313.0, sd: 0, p2_5: 105.6, p5: 133.1, p10: 167.6, p25: 231.8, p50: 313.0, p75: 400.6, p90: 480.8, p95: 529.2, p97_5: 571.4 },
  { ageYears: 13, ageMonths: 0, mean: 321.7, sd: 0, p2_5: 109.7, p5: 138.8, p10: 174.7, p25: 240.4, p50: 321.7, p75: 407.8, p90: 485.3, p95: 531.5, p97_5: 571.7 },
  { ageYears: 14, ageMonths: 0, mean: 311.2, sd: 0, p2_5: 108.2, p5: 136.9, p10: 171.9, p25: 234.8, p50: 311.2, p75: 390.6, p90: 461.1, p95: 502.8, p97_5: 538.8 },
  { ageYears: 15, ageMonths: 0, mean: 288.1, sd: 0, p2_5: 103.0, p5: 129.9, p10: 162.3, p25: 219.7, p50: 288.1, p75: 358.1, p90: 419.6, p95: 455.7, p97_5: 486.6 },
  { ageYears: 16, ageMonths: 0, mean: 262.8, sd: 0, p2_5: 97.4, p5: 122.0, p10: 151.4, p25: 202.7, p50: 262.8, p75: 323.6, p90: 376.4, p95: 407.2, p97_5: 433.5 },
  { ageYears: 17, ageMonths: 0, mean: 245.0, sd: 0, p2_5: 94.7, p5: 117.6, p10: 144.6, p25: 191.1, p50: 245.0, p75: 298.8, p90: 345.2, p95: 372.1, p97_5: 394.9 },
  { ageYears: 18, ageMonths: 0, mean: 231.8, sd: 0, p2_5: 93.9, p5: 115.3, p10: 140.3, p25: 183.0, p50: 231.8, p75: 280.1, p90: 321.4, p95: 345.2, p97_5: 365.4 },
];

// Male Bone Age (Table 2) - User-verified data
const maleBoneAge: ReferenceRow[] = [
  { ageYears: 5, ageMonths: 0, mean: 97.3, sd: 0, p2_5: 34.2, p5: 42.2, p10: 52.5, p25: 72.2, p50: 97.3, p75: 127.2, p90: 160.0, p95: 182.5, p97_5: 203.9 },
  { ageYears: 6, ageMonths: 0, mean: 108.6, sd: 0, p2_5: 39.9, p5: 48.5, p10: 59.7, p25: 81.0, p50: 108.6, p75: 141.7, p90: 178.2, p95: 203.6, p97_5: 227.9 },
  { ageYears: 7, ageMonths: 0, mean: 120.9, sd: 0, p2_5: 46.0, p5: 55.4, p10: 67.5, p25: 90.8, p50: 120.9, p75: 157.1, p90: 197.5, p95: 225.6, p97_5: 252.6 },
  { ageYears: 8, ageMonths: 0, mean: 133.9, sd: 0, p2_5: 52.3, p5: 62.6, p10: 75.8, p25: 101.2, p50: 133.9, p75: 173.2, p90: 217.0, p95: 247.6, p97_5: 276.9 },
  { ageYears: 9, ageMonths: 0, mean: 145.5, sd: 0, p2_5: 58.0, p5: 69.2, p10: 83.4, p25: 110.6, p50: 145.5, p75: 187.2, p90: 233.4, p95: 265.5, p97_5: 296.3 },
  { ageYears: 10, ageMonths: 0, mean: 154.3, sd: 0, p2_5: 62.5, p5: 74.4, p10: 89.5, p25: 118.0, p50: 154.3, p75: 197.3, p90: 244.4, p95: 276.9, p97_5: 307.9 },
  { ageYears: 11, ageMonths: 0, mean: 167.6, sd: 0, p2_5: 68.6, p5: 81.6, p10: 98.1, p25: 129.0, p50: 167.6, p75: 212.8, p90: 261.6, p95: 294.8, p97_5: 326.3 },
  { ageYears: 12, ageMonths: 0, mean: 198.8, sd: 0, p2_5: 81.8, p5: 97.6, p10: 117.4, p25: 153.9, p50: 198.8, p75: 250.2, p90: 305.0, p95: 341.8, p97_5: 376.3 },
  { ageYears: 13, ageMonths: 0, mean: 252.3, sd: 0, p2_5: 104.0, p5: 124.6, p10: 150.2, p25: 196.5, p50: 252.3, p75: 315.0, p90: 380.2, p95: 423.5, p97_5: 463.6 },
  { ageYears: 14, ageMonths: 0, mean: 309.7, sd: 0, p2_5: 127.2, p5: 153.5, p10: 185.6, p25: 242.7, p50: 309.7, p75: 383.2, p90: 457.9, p95: 506.7, p97_5: 551.4 },
  { ageYears: 15, ageMonths: 0, mean: 340.6, sd: 0, p2_5: 138.8, p5: 169.1, p10: 205.5, p25: 268.6, p50: 340.6, p75: 417.5, p90: 493.9, p95: 542.9, p97_5: 587.3 },
  { ageYears: 16, ageMonths: 0, mean: 337.5, sd: 0, p2_5: 135.9, p5: 167.6, p10: 204.9, p25: 267.8, p50: 337.5, p75: 409.7, p90: 479.8, p95: 523.9, p97_5: 563.5 },
  { ageYears: 17, ageMonths: 0, mean: 307.9, sd: 0, p2_5: 122.2, p5: 152.9, p10: 188.2, p25: 246.0, p50: 307.9, p75: 370.1, p90: 429.1, p95: 465.6, p97_5: 498.0 },
  { ageYears: 18, ageMonths: 0, mean: 267.9, sd: 0, p2_5: 105.2, p5: 133.4, p10: 165.1, p25: 215.7, p50: 267.9, p75: 319.0, p90: 366.2, p95: 395.0, p97_5: 420.1 },
];

// Female Bone Age (Table 2) - User-verified data
const femaleBoneAge: ReferenceRow[] = [
  { ageYears: 5, ageMonths: 0, mean: 124.3, sd: 0, p2_5: 51.6, p5: 59.3, p10: 69.7, p25: 91.5, p50: 124.3, p75: 168.3, p90: 218.8, p95: 255.1, p97_5: 290.7 },
  { ageYears: 6, ageMonths: 0, mean: 131.8, sd: 0, p2_5: 52.9, p5: 61.6, p10: 73.2, p25: 97.1, p50: 131.8, p75: 176.1, p90: 224.5, p95: 257.8, p97_5: 289.5 },
  { ageYears: 7, ageMonths: 0, mean: 139.7, sd: 0, p2_5: 54.4, p5: 64.2, p10: 77.1, p25: 103.1, p50: 139.7, p75: 184.5, p90: 231.4, p95: 262.7, p97_5: 291.7 },
  { ageYears: 8, ageMonths: 0, mean: 149.2, sd: 0, p2_5: 56.5, p5: 67.6, p10: 82.0, p25: 110.5, p50: 149.2, p75: 195.1, p90: 241.5, p95: 271.6, p97_5: 299.1 },
  { ageYears: 9, ageMonths: 0, mean: 165.9, sd: 0, p2_5: 61.3, p5: 74.2, p10: 90.9, p25: 123.2, p50: 165.9, p75: 214.9, p90: 263.0, p95: 293.6, p97_5: 321.1 },
  { ageYears: 10, ageMonths: 0, mean: 196.6, sd: 0, p2_5: 71.2, p5: 87.3, p10: 107.8, p25: 146.6, p50: 196.6, p75: 252.5, p90: 306.2, p95: 339.7, p97_5: 369.7 },
  { ageYears: 11, ageMonths: 0, mean: 241.9, sd: 0, p2_5: 86.6, p5: 107.2, p10: 133.0, p25: 181.1, p50: 241.9, p75: 308.3, p90: 370.9, p95: 409.5, p97_5: 443.6 },
  { ageYears: 12, ageMonths: 0, mean: 295.3, sd: 0, p2_5: 105.3, p5: 131.2, p10: 163.4, p25: 222.3, p50: 295.3, p75: 373.7, p90: 446.6, p95: 491.1, p97_5: 530.2 },
  { ageYears: 13, ageMonths: 0, mean: 340.2, sd: 0, p2_5: 122.0, p5: 152.5, p10: 189.9, p25: 257.6, p50: 340.2, p75: 427.9, p90: 508.3, p95: 557.1, p97_5: 599.8 },
  { ageYears: 14, ageMonths: 0, mean: 350.2, sd: 0, p2_5: 127.4, p5: 159.0, p10: 197.6, p25: 266.8, p50: 350.2, p75: 437.8, p90: 517.6, p95: 565.7, p97_5: 607.6 },
  { ageYears: 15, ageMonths: 0, mean: 315.8, sd: 0, p2_5: 117.5, p5: 146.0, p10: 180.6, p25: 242.1, p50: 315.8, p75: 392.6, p90: 462.3, p95: 504.1, p97_5: 540.4 },
  { ageYears: 16, ageMonths: 0, mean: 270.5, sd: 0, p2_5: 103.7, p5: 127.9, p10: 157.0, p25: 208.1, p50: 270.5, p75: 334.6, p90: 392.5, p95: 427.2, p97_5: 457.4 },
  { ageYears: 17, ageMonths: 0, mean: 240.7, sd: 0, p2_5: 95.6, p5: 116.7, p10: 142.1, p25: 187.1, p50: 240.7, p75: 296.3, p90: 346.6, p95: 376.7, p97_5: 402.9 },
  { ageYears: 18, ageMonths: 0, mean: 225.2, sd: 0, p2_5: 93.1, p5: 112.3, p10: 135.4, p25: 176.4, p50: 225.2, p75: 276.1, p90: 322.2, p95: 349.8, p97_5: 373.8 },
];

// Tanner Stage Reference Data (Table 3) - User-verified data
const tannerStageData: TannerReferenceRow[] = [
  // Male Tanner Stages
  { sex: 'male', tannerStage: 1, mean: 138.8, sd: 0, p2_5: 46.6, p5: 58.9, p10: 74.4, p25: 103.3, p50: 138.8, p75: 179.5, p90: 223.4, p95: 253.1, p97_5: 281.0 },
  { sex: 'male', tannerStage: 2, mean: 209.3, sd: 0, p2_5: 86.5, p5: 103.7, p10: 125.0, p25: 163.4, p50: 209.3, p75: 260.9, p90: 315.6, p95: 352.3, p97_5: 386.5 },
  { sex: 'male', tannerStage: 3, mean: 304.8, sd: 0, p2_5: 124.9, p5: 150.0, p10: 181.2, p25: 237.5, p50: 304.8, p75: 380.5, p90: 460.8, p95: 514.7, p97_5: 565.1 },
  { sex: 'male', tannerStage: 4, mean: 302.6, sd: 0, p2_5: 145.4, p5: 168.3, p10: 196.0, p25: 245.2, p50: 302.6, p75: 366.2, p90: 432.6, p95: 476.8, p97_5: 517.8 },
  { sex: 'male', tannerStage: 5, mean: 311.5, sd: 0, p2_5: 149.6, p5: 173.1, p10: 201.7, p25: 252.3, p50: 311.5, p75: 377.0, p90: 445.4, p95: 490.9, p97_5: 533.1 },
  // Female Tanner Stages
  { sex: 'female', tannerStage: 1, mean: 155.6, sd: 0, p2_5: 47.4, p5: 61.6, p10: 79.7, p25: 113.4, p50: 155.6, p75: 203.1, p90: 251.7, p95: 283.3, p97_5: 312.3 },
  { sex: 'female', tannerStage: 2, mean: 229.9, sd: 0, p2_5: 83.0, p5: 103.0, p10: 127.9, p25: 173.8, p50: 229.9, p75: 292.5, p90: 355.8, p95: 396.8, p97_5: 434.3 },
  { sex: 'female', tannerStage: 3, mean: 304.5, sd: 0, p2_5: 130.8, p5: 155.2, p10: 185.3, p25: 239.4, p50: 304.5, p75: 376.0, p90: 447.5, p95: 493.6, p97_5: 535.5 },
  { sex: 'female', tannerStage: 4, mean: 345.0, sd: 0, p2_5: 137.0, p5: 165.9, p10: 201.5, p25: 266.4, p50: 345.0, p75: 431.9, p90: 519.3, p95: 575.8, p97_5: 627.3 },
  { sex: 'female', tannerStage: 5, mean: 274.8, sd: 0, p2_5: 104.9, p5: 128.3, p10: 157.3, p25: 210.3, p50: 274.8, p75: 346.4, p90: 418.5, p95: 465.2, p97_5: 507.8 },
];

// Reference tables with source metadata
const referenceTables: ReferenceTable[] = [
  {
    sex: 'male',
    ageBasis: 'chronological',
    rows: maleChronologicalAge,
    sourceTable: 'Table 1',
  },
  {
    sex: 'female',
    ageBasis: 'chronological',
    rows: femaleChronologicalAge,
    sourceTable: 'Table 1',
  },
  {
    sex: 'male',
    ageBasis: 'bone',
    rows: maleBoneAge,
    sourceTable: 'Table 2',
  },
  {
    sex: 'female',
    ageBasis: 'bone',
    rows: femaleBoneAge,
    sourceTable: 'Table 2',
  },
];

/**
 * Find the appropriate reference table for a given sex and age basis
 */
export function findReferenceTable(
  sex: 'male' | 'female',
  ageBasis: 'chronological' | 'bone'
): ReferenceTable | null {
  return referenceTables.find((t) => t.sex === sex && t.ageBasis === ageBasis) || null;
}

/**
 * Find the closest reference row for a given age
 */
export function findReferenceRow(
  table: ReferenceTable,
  ageYears: number,
  ageMonths: number
): ReferenceRow | null {
  const targetAgeInMonths = ageYears * 12 + ageMonths;

  // Find the closest row
  let closestRow: ReferenceRow | null = null;
  let minDiff = Infinity;

  for (const row of table.rows) {
    const rowAgeInMonths = row.ageYears * 12 + row.ageMonths;
    const diff = Math.abs(targetAgeInMonths - rowAgeInMonths);

    if (diff < minDiff) {
      minDiff = diff;
      closestRow = row;
    }
  }

  return closestRow;
}

/**
 * Find the Tanner stage reference row for a given sex and stage
 */
export function findTannerReferenceRow(
  sex: 'male' | 'female',
  tannerStage: 1 | 2 | 3 | 4 | 5
): TannerReferenceRow | null {
  return tannerStageData.find((row) => row.sex === sex && row.tannerStage === tannerStage) || null;
}
